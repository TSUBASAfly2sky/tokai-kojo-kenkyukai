# 東海古城研究会 ホームページ

愛知・岐阜・三重・静岡の古城・城跡を調査・研究する「東海古城研究会」のホームページです。
GitHub Pagesで公開できる静的サイトとして構築しています。

## ファイル構成

```
.
├── index.html       … トップページ
├── report.html      … 活動報告一覧ページ
├── admin.html       … 管理画面（パスワード保護）
├── data.json        … お知らせ・活動報告のデータ
├── css/
│   └── style.css    … スタイルシート
├── js/
│   ├── data.js      … データ読み込み・表示ロジック
│   └── admin.js     … 管理画面ロジック
├── .nojekyll        … GitHub Pages 用の設定ファイル
└── README.md        … この説明書
```

## GitHub Pages で公開する手順

### 1. GitHubのアカウントを作成

https://github.com/ にアクセスして無料アカウントを作成してください。

### 2. リポジトリを作成

1. 右上の「+」→「New repository」をクリック
2. リポジトリ名を入力（例：`tokai-kojo-site`）
3. 「Public」を選択
4. 「Create repository」をクリック

### 3. ファイルをアップロード

作成されたリポジトリ画面で：

1. 「uploading an existing file」リンクをクリック
2. このフォルダの **すべてのファイル・フォルダ** をドラッグ＆ドロップ
3. ページ下部の「Commit changes」をクリック

### 4. GitHub Pages を有効化

1. リポジトリのトップで「Settings」タブを開く
2. 左メニューの「Pages」をクリック
3. 「Source」を **「Deploy from a branch」** に設定
4. 「Branch」を **「main」**、フォルダは **「/ (root)」** にして「Save」

数分後、`https://(あなたのGitHubユーザー名).github.io/tokai-kojo-site/` でサイトが公開されます。

## 管理画面の使い方

### 初回ログイン

1. `https://(公開URL)/admin.html` にアクセス
2. パスワード： **`tokai1960`**
3. ログイン後、必ず「設定」タブからパスワードを変更してください

### お知らせ・活動報告の追加

1. 「お知らせ管理」または「活動報告管理」タブを開く
2. フォームに入力して「保存する」を押す
3. ブラウザ内（localStorage）に保存されます

### 公開サイトへの反映（重要）

管理画面で編集した内容は **そのブラウザ内にのみ保存** されます。
公開サイトに反映するには次の手順を実行してください：

1. 管理画面右上の **「📥 JSON書き出し」** をクリック → `data.json` がダウンロードされます
2. GitHubのリポジトリで `data.json` ファイルを開く
3. 鉛筆マーク（Edit）をクリック
4. 中身を全選択して削除し、ダウンロードした `data.json` の中身を貼り付け
5. 下部の「Commit changes」をクリック
6. 1〜2分後、公開サイトに反映されます

> 💡 **補足**：他のブラウザや別のPCで編集する場合は、まず「📤 JSON読み込み」で最新の `data.json` を読み込んでから編集してください。

## お問い合わせフォームについて

Googleフォームを iframe で埋め込んでいます。
フォームへの回答はGoogleスプレッドシートで管理できます。詳細は管理画面の「設定」タブをご参照ください。

フォームURL（変更時は `index.html` の `<iframe>` タグを修正）：
```
https://docs.google.com/forms/d/e/1FAIpQLSdv9U6BF75r1oWcRdBS3N-3Q_ptprey6gVxW3IBDNYQ6Gburg/viewform?embedded=true
```

## カスタマイズ

- **配色を変える**：`css/style.css` の冒頭 `:root { ... }` 内のカラー変数を編集
- **会の情報を変える**：`index.html` の `info-table` を編集
- **ロゴを変える**：`index.html` `report.html` `admin.html` 冒頭の `<svg class="logo-mark">` を編集

## ライセンス

このサイトのコードは自由に利用・改変いただけます。
